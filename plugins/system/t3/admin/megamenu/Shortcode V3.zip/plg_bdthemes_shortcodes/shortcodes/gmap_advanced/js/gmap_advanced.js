
jQuery(document).ready(function ($) {

	$('.su_gmap_advanced.map-as-background').parent('div').addClass('map-as-background-wrapper');

});
