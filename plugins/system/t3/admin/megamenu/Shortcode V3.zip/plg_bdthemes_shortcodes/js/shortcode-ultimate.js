jQuery(document).ready(function($) {
	'use strict';

	$('body').addClass('su-shortcodes-loaded');
		
});